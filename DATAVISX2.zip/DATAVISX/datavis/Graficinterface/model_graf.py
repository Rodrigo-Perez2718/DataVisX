import sys
import pandas as pd
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenuBar, QMenu, QAction, QFileDialog, QTableWidget, QTableWidgetItem, QComboBox, QHBoxLayout, QVBoxLayout, QPushButton, QWidget, QLineEdit, QLabel
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from datavis.Clustering import model_cluster as mc
from datavis.Regresion import model_reg as mr

# Definir la clase de la ventana principal que hereda de QMainWindow
class MainWindow(QMainWindow):
    """
    Para utilizar la interfaz gráfica, es necesario importar el módulo model_graf desde el paquete datavis.Graficinterface. 
    Además, se importa el módulo QApplication de PyQt5 para crear la aplicación gráfica:

    from datavis.Graficinterface import model_graf as mg
    import sys
    from PyQt5.QtWidgets import QApplication
    if __name__ == "__main__":
        app = QApplication(sys.argv)
        window = mg.MainWindow()
        window.show()
        sys.exit(app.exec_()) 
    
    En este código, se crea una instancia de QApplication para inicializar la aplicación gráfica.
    Luego, se crea una instancia de MainWindow desde el módulo model_graf y se muestra la ventana.
    Finalmente, se inicia el bucle de la aplicación utilizando app.exec_().
    """
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DataVisX")
        self.setMinimumSize(1200, 1000)  # Establecer el tamaño mínimo de la ventana

        # Crear la barra de menú y el menú "Archivo" con la opción "Abrir archivo"
        self.create_menu_bar()

        # Crear los widgets: tabla, selectores, botones y campos de entrada
        self.create_widgets()

        # Crear el diseño de la ventana con disposición vertical y varios sub-layouts
        self.create_layout()

        # Inicializar la variable para almacenar el DataFrame
        self.data_frame = None

    def create_menu_bar(self):
        menu_bar = self.menuBar()  # Crear la barra de menú

        # Crear el menú "Archivo"
        file_menu = QMenu("Archivo", self)
        menu_bar.addMenu(file_menu)

        # Crear la acción "Abrir archivo" y conectarla a la función open_file_dialog
        open_action = QAction("Abrir archivo", self)
        open_action.triggered.connect(self.open_file_dialog)
        file_menu.addAction(open_action)

    def create_widgets(self):
        # Crear la tabla para mostrar el DataFrame
        self.table_widget = QTableWidget(self)

        # Crear los selectores para elegir las columnas en el eje x e y
        self.x_selector = QComboBox(self)
        self.y_selector = QComboBox(self)

        # Crear el botón "Actualizar Gráfico" y conectarlo a la función update_graph
        self.plot_button = QPushButton("Actualizar Gráfico", self)
        self.plot_button.clicked.connect(self.update_graph)

        # Crear los botones para realizar las tareas de agrupamiento y regresión
        self.dbscan_button = QPushButton("DBSCAN Clustering", self)
        self.dbscan_button.clicked.connect(self.perform_dbscan)

        self.kmeans_button = QPushButton("K-Means Clustering", self)
        self.kmeans_button.clicked.connect(self.perform_kmeans)

        self.log_reg_button = QPushButton("Regresión Logística", self)
        self.log_reg_button.clicked.connect(self.perform_log_regression)

        self.linear_reg_button = QPushButton("Regresión Lineal", self)
        self.linear_reg_button.clicked.connect(self.perform_linear_regression)

        # Crear los campos de entrada para los parámetros de DBSCAN y regresión
        self.eps_input = QLineEdit(self)
        self.eps_input.setPlaceholderText("Valor de eps para DBSCAN")

        self.min_samples_input = QLineEdit(self)
        self.min_samples_input.setPlaceholderText("Valor de min_samples para DBSCAN")

        self.test_size_input = QLineEdit(self)
        self.test_size_input.setPlaceholderText("Tamaño de prueba para Regresión Logística")

        self.random_state_input = QLineEdit(self)
        self.random_state_input.setPlaceholderText("Valor de random_state para Regresión Logística")

        # Crear campos de entrada para los títulos generales de clustering y regresión
        self.clustering_title_input = QLineEdit(self)
        self.clustering_title_input.setPlaceholderText("Título general para clustering")

        self.regression_title_input = QLineEdit(self)
        self.regression_title_input.setPlaceholderText("Título general para regresión")

        # Crear campo de entrada para el número de clusters en K-Means
        self.n_clusters_input = QLineEdit(self)
        self.n_clusters_input.setPlaceholderText("Número de clusters para K-Means")

        # Crear la figura y el lienzo para mostrar la gráfica
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)

    def create_layout(self):
        central_widget = QWidget(self)  # Crear el widget central

        layout = QVBoxLayout(central_widget)  # Crear el layout principal con disposición vertical

        # Agregar la tabla al layout principal
        layout.addWidget(self.table_widget)

        # Crear un layout horizontal para los selectores de columna y el botón "Actualizar Gráfico"
        selector_layout = QHBoxLayout()
        selector_layout.addWidget(self.x_selector)
        selector_layout.addWidget(self.y_selector)
        selector_layout.addWidget(self.plot_button)
        layout.addLayout(selector_layout)

        # Agregar el lienzo de la gráfica al layout principal
        plot_clustering_layout = QVBoxLayout()
        plot_clustering_layout.addWidget(self.canvas)
        layout.addLayout(plot_clustering_layout)

        # Crear un layout vertical para el botón "DBSCAN Clustering" y campos de entrada relacionados
        clustering_layout = QVBoxLayout()
        clustering_layout.addWidget(self.dbscan_button)
        clustering_layout.addWidget(self.eps_input)
        clustering_layout.addWidget(self.min_samples_input)
        clustering_layout.addWidget(QLabel("Título general para clustering:"))  # Etiqueta para el título general
        clustering_layout.addWidget(self.clustering_title_input)  # Campo de entrada para el título general de agrupamiento
        layout.addLayout(clustering_layout)

        # Crear un layout vertical para los botones de regresión y campos de entrada relacionados
        regression_layout = QVBoxLayout()
        regression_layout.addWidget(self.log_reg_button)
        regression_layout.addWidget(self.test_size_input)
        regression_layout.addWidget(self.random_state_input)
        regression_layout.addWidget(self.linear_reg_button)
        regression_layout.addWidget(QLabel("Título general para regresión:"))  # Etiqueta para el título general
        regression_layout.addWidget(self.regression_title_input)  # Campo de entrada para el título general de regresión
        layout.addLayout(regression_layout)

        # Agregar el botón "K-Means Clustering" y campo de entrada relacionado al layout principal
        layout.addWidget(self.kmeans_button)
        layout.addWidget(QLabel("Número de clusters para K-Means:"))  # Etiqueta para el campo de entrada
        layout.addWidget(self.n_clusters_input)  # Campo de entrada para el número de clusters en K-Means

        # Establecer el layout principal como el widget central
        self.setCentralWidget(central_widget)

    def open_file_dialog(self):
        options = QFileDialog.Options()
        file_path, _ = QFileDialog.getOpenFileName(self, "Seleccionar archivo", "", "CSV Files (*.csv)", options=options)

        if file_path:
            self.data_frame = pd.read_csv(file_path)
            self.display_data_frame()

    def display_data_frame(self):
        self.table_widget.clear()
        self.x_selector.clear()
        self.y_selector.clear()
        self.table_widget.setColumnCount(0)
        self.table_widget.setRowCount(0)

        if self.data_frame is not None:
            num_rows, num_cols = self.data_frame.shape
            self.table_widget.setRowCount(num_rows)
            self.table_widget.setColumnCount(num_cols)

            self.x_selector.addItems(self.data_frame.columns)
            self.y_selector.addItems(self.data_frame.columns)

            column_names = self.data_frame.columns.tolist()
            self.table_widget.setHorizontalHeaderLabels(column_names)

            for i in range(num_rows):
                for j in range(num_cols):
                    item = QTableWidgetItem(str(self.data_frame.iat[i, j]))
                    self.table_widget.setItem(i, j, item)

    def update_graph(self):
        x_column = self.x_selector.currentText()
        y_column = self.y_selector.currentText()

        if x_column and y_column and self.data_frame is not None:
            self.figure.clear()
            ax = self.figure.add_subplot(111)

            ax.plot(self.data_frame[x_column], self.data_frame[y_column], marker='o', linestyle='')

            ax.set_xlabel(x_column)
            ax.set_ylabel(y_column)

            ax.grid(linestyle="--")

            self.canvas.draw()

    def perform_dbscan(self):
        """
        Realiza el DBSCAN clustering en los datos seleccionados y muestra el gráfico de dispersión.

        Este método obtiene las opciones seleccionadas por el usuario, como los nombres de las columnas
        para el eje x e y, el valor de epsilon (eps) y el número mínimo de muestras (min_samples) para
        el algoritmo DBSCAN. Luego, utiliza el módulo model_cluster para realizar el clustering y visualizar
        los resultados mediante la creación de una instancia de la clase Astrodata y llamando al método DBSCAn.

        """
        x_column = self.x_selector.currentText()
        y_column = self.y_selector.currentText()

        if x_column and y_column and self.data_frame is not None:
            x_data = self.data_frame[x_column].values
            y_data = self.data_frame[y_column].values

            eps = float(self.eps_input.text()) if self.eps_input.text() else 0.5
            min_samples = int(self.min_samples_input.text()) if self.min_samples_input.text() else 5
            title = self.clustering_title_input.text() if self.clustering_title_input.text() else "DBSCAN Clustering"
            x_label = x_column
            y_label = y_column

            astrodata = mc.Astrodata(x_data, y_data)
            astrodata.DBSCAn(eps=eps, title=title, min_samples=min_samples, x_label=x_label, y_label=y_label)

    def perform_kmeans(self):
        """
        Realiza el K-Means clustering en los datos seleccionados y muestra el gráfico de dispersión.

        Este método obtiene las opciones seleccionadas por el usuario, como los nombres de las columnas
        para el eje x e y, y el número de clusters para el algoritmo K-Means. Luego, utiliza el módulo
        model_cluster para realizar el clustering y visualizar los resultados mediante la creación de una
        instancia de la clase Astrodata y llamando al método Kme.

        """
        x_column = self.x_selector.currentText()
        y_column = self.y_selector.currentText()

        if x_column and y_column and self.data_frame is not None:
            x_data = self.data_frame[x_column].values
            y_data = self.data_frame[y_column].values

            n_clusters = int(self.n_clusters_input.text()) if self.n_clusters_input.text() else 3
            title = self.clustering_title_input.text() if self.clustering_title_input.text() else "K-Means Clustering"
            x_label = x_column
            y_label = y_column

            astrodata = mc.Astrodata(x_data, y_data)
            astrodata.Kme(n_clusters=n_clusters, title=title, x_label=x_label, y_label=y_label)

    def perform_log_regression(self):
        x_column = self.x_selector.currentText()
        y_column = self.y_selector.currentText()

        if x_column and y_column and self.data_frame is not None:
            x_data = self.data_frame[x_column].values
            y_data = self.data_frame[y_column].values

            test_size = float(self.test_size_input.text()) if self.test_size_input.text() else 0.2
            random_state = int(self.random_state_input.text()) if self.random_state_input.text() else 42
            title = self.regression_title_input.text() if self.regression_title_input.text() else "Regresión Logística"
            x_label = x_column
            y_label = y_column
            # Crear una instancia de la clase AstroReg y realizar la regresión logística
            
            astroreg = mr.AstroReg(x_data, y_data)
            astroreg.log_regresion(test_size=test_size, random_state=random_state, title=title, x_label=x_label, y_label=y_label)

    def perform_linear_regression(self):
        """
        Realiza la regresión lineal en los datos seleccionados y muestra la línea de regresión.

        Este método obtiene las opciones seleccionadas por el usuario, como los nombres de las columnas
        para el eje x e y. Luego, utiliza el módulo model_reg para realizar la regresión y visualizar los
        resultados mediante la creación de una instancia de la clase AstroReg y llamando al método Linear_regresion.

        """
        x_column = self.x_selector.currentText()
        y_column = self.y_selector.currentText()

        if x_column and y_column and self.data_frame is not None:
            x_data = self.data_frame[x_column].values
            y_data = self.data_frame[y_column].values

            title = self.regression_title_input.text() if self.regression_title_input.text() else "Regresión Lineal"
            x_label = x_column
            y_label = y_column
            
            # Crear una instancia de la clase AstroReg y realizar la regresión lineal
            astroreg = mr.AstroReg(x_data, y_data)
            astroreg.Linear_regresion(title=title, x_label=x_label, y_label=y_label)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

