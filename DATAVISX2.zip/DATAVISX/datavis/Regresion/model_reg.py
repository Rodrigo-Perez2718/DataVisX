from sklearn.linear_model import LogisticRegression , LinearRegression
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import StandardScaler

class AstroReg:
    """
    AstroReg es una clase para realizar regresiones lineales y de regresión logística utilizando la biblioteca scikit-learn.
    
    Modo de uso:
        - Para realizar una regresión lineal:
          astro_reg = AstroReg(x, y)
          astro_reg.Linear_regresion(title='Título del gráfico', x_label='Etiqueta eje x', y_label='Etiqueta eje y')

        - Para realizar una regresión logística:
          astro_reg = AstroReg(x, y)
          astro_reg.log_regresion(test_size=0.2, random_state=42, title='Título del gráfico', x_label='Etiqueta eje x', y_label='Etiqueta eje y')

    Parámetros:
        x (array-like): Datos de entrada que representan los valores del eje x, serán transformados a una matriz numpy.
        y (array-like): Datos de entrada que representan los valores del eje y, serán transformados a una matriz numpy.
    """
    def __init__(self, x, y):
        # Se definen las variables x, y a trabajar y se convierten en un array para su trabajo
        self.x = np.array(x)
        self.y = np.array(y)
    
    def log_regresion(self, test_size, random_state=42, title='titulo', x_label='eje x', y_label='eje y'):
        # Establecer los atributos del objeto para ser usados más tarde en el método
        self.test_size = test_size
        self.random_state = random_state
        self.x_label = x_label
        self.y_label = y_label
        self.title = title

        # Dividir los datos en conjuntos de entrenamiento y prueba
        X_train, X_test, y_train, y_test = train_test_split(self.x, self.y, test_size=self.test_size, random_state=self.random_state)

        # Crear un modelo de regresión logística
        log_reg = LogisticRegression()

        # Ajustar el modelo con los datos de entrenamiento
        log_reg.fit(X_train, y_train)

        # Realizar predicciones en el conjunto de prueba
        y_pred = log_reg.predict(X_test)

        # Crear una figura y dibujar dos gráficos
        plt.figure(figsize=(8, 8))
        
        # Gráfico 1: Datos de prueba con colores según la variable objetivo (y_test)
        plt.subplot(2, 1, 1)
        plt.scatter(X_test[:, 0], X_test[:, 1], c=y_test)
        plt.xlabel(self.x_label)
        plt.ylabel(self.y_label)
        plt.title(self.title)
        plt.tight_layout()

        # Gráfico 2: Predicciones con colores según las predicciones (y_pred)
        plt.subplot(2, 1, 2)
        plt.scatter(X_test[:, 0], X_test[:, 1], c=y_pred)
        plt.xlabel(self.x_label)
        plt.ylabel(self.y_label)
        plt.title('Predicted- ' + self.title)
        plt.tight_layout()

        # Mostrar los gráficos
        plt.show()
    def Linear_regresion(self, title, x_label, y_label,):
        self.x = self.x.reshape(-1, 1)
        self.y = self.y.reshape(-1,1)
        model = LinearRegression()
        model.fit(self.x, self.y)
        predictions = model.predict(self.x)
        # Plot the actual values and the predicted values
        plt.scatter(self.y, predictions)
        plt.plot([self.y.min(), self.y.max()], [self.y.min(), self.y.max()], color='red', linestyle='--')
        plt.xlabel(x_label)
        plt.ylabel(y_label)
        plt.title(title)
        plt.show()