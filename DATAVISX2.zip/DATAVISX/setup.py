from setuptools import setup

setup(
    name = 'datavis',
    version = '2.0.0',
    license = 'MIT',
    description = ' Librería para visualización de datos con herramientas de clustering y regresión',
    author = 'Rodigo Pérez - Gabriela Segura - Javier Gallardo - Amirah luna izidine',
    install_requires = ['numpy','matplotlib','scipy','scikit-learn', 'PyQt5', 'Pandas']
)
